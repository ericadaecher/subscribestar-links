# Subscribestar Links

Fix the Subscribestar external links

## Installation

1. Download and Extract **subscribestar-links.zip** on your computer
   - https://github.com/ericadaecher/subscribestar-links/raw/main/subscribestar-links.zip
2. Open the Chrome Extension Management page by navigating to `chrome://extensions`
3. Enable **Developer Mode** by clicking the toggle switch next to Developer mode.
4. Click the **Load unpacked** button and select the extension directory.
